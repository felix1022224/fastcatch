//
//  MainBanner.swift
//  FelixFastCatch
//
//  Created by 卢凡 on 2017/7/27.
//  Copyright © 2017年 felix. All rights reserved.
//

import UIKit

class MainBanner: NSObject {
    
    
    
}
