//
//  ProductinfoDialog.swift
//  FelixFastCatch
//
//  Created by 卢凡 on 2017/8/26.
//  Copyright © 2017年 felix. All rights reserved.
//

import UIKit

class ProductinfoDialog: BaseDialog {

    

}
